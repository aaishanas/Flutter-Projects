// ignore_for_file: prefer_const_constructors, dead_code, unnecessary_import, implementation_imports

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:my_first/Pages/page_1.dart';
import 'package:my_first/Pages/page_10.dart';
import 'package:my_first/Pages/page_2.dart';
import 'package:my_first/Pages/page_3.dart';
import 'package:my_first/Pages/page_4.dart';
import 'package:my_first/Pages/page_5.dart';
import 'package:my_first/Pages/page_6.dart';
import 'package:my_first/Pages/page_7.dart';
import 'package:my_first/Pages/page_9.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'Pages/page_8.dart';

class Homepage extends StatelessWidget {
  final _controller = PageController();
  Homepage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final pages = [
      const Page1(),
      const Page2(),
      const Page3(),
      const Page4(),
      const Page5(),
      const Page6(),
      const Page7(),
      const Page8(),
      const Page9(),
      const Page10(),
    ];
    style:
    TextStyle(color: Colors.indigo);

    return Scaffold(
      body: Column(children: [
        SizedBox(
          width: double.infinity,
          height: 700,
          child: PageView.builder(
            controller: _controller,
            itemCount: pages.length,
            itemBuilder: (_, index) {
              return pages[index];
            },
          ),
        ),
        SmoothPageIndicator(
          controller: _controller,
          count: 3,
          effect: ExpandingDotsEffect(
              dotColor: Colors.black12,
              activeDotColor: Colors.green,
              dotHeight: 10,
              dotWidth: 10,
              spacing: 12),
        ),
      ]),
    );
  }
}
