// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

import 'package:my_first/Pages/page_9.dart';

class Page8 extends StatelessWidget {
  const Page8({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          Center(
            child: Container(
                child:
                    Image(image: AssetImage('Assets/images/splashscreen.png'))),
          ),
          Center(
              child: Text(
            'Verification',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          )),
          Center(child: Text('Enter OTP code sent your number')),
          Padding(
            padding: const EdgeInsets.only(top: 75),
            child: Myotp(),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 90),
            child: ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Page9()));
              },
              child: Text('Submit'),
            ),
          ),
        ],
      ),
    );
  }
}

class Myotp extends StatelessWidget {
  const Myotp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Form(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          SizedBox(
            height: 64,
            width: 60,
            child: TextField(
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                  fillColor: Color.fromARGB(255, 84, 220, 88),
                  border: OutlineInputBorder()),
            ),
          ),
          SizedBox(
            width: 10,
          ),
          SizedBox(
            height: 64,
            width: 60,
            child: TextField(
              textAlign: TextAlign.center,
              decoration: InputDecoration(border: OutlineInputBorder()),
            ),
          ),
          SizedBox(
            width: 10,
          ),
          SizedBox(
            height: 64,
            width: 60,
            child: TextField(
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                fillColor: Color.fromARGB(255, 84, 220, 88),
                border: OutlineInputBorder(),
              ),
            ),
          ),
          SizedBox(
            width: 10,
          ),
          SizedBox(
            height: 64,
            width: 60,
            child: TextField(
              textAlign: TextAlign.center,
              decoration: InputDecoration(
                  fillColor: Color.fromARGB(255, 84, 220, 88),
                  border: OutlineInputBorder()),
            ),
          ),
        ],
      ),
    );
  }
}
