// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:my_first/Pages/page_8.dart';

class Page7 extends StatefulWidget {
  const Page7({Key? key}) : super(key: key);

  @override
  State<Page7> createState() => _Page7State();
}

class _Page7State extends State<Page7> {
  final _formKey = GlobalKey<FormState>();

  List<String> items = [
    "",
    "Andhra Pradesh",
    "Arunachal Pradesh ",
    "Assam",
    "Bihar",
    "Chhattisgarh",
    "Goa",
    "Gujarat",
    "Haryana",
    "Himachal Pradesh",
    "Jammu and Kashmir",
    "Jharkhand",
    "Karnataka",
    "Kerala",
    "Madhya Pradesh",
    "Maharashtra",
    "Manipur",
    "Meghalaya",
    "Mizoram",
    "Nagaland",
    "Odisha",
    "Punjab",
    "Rajasthan",
    "Sikkim",
    "Tamil Nadu",
    "Telangana",
    "Tripura",
    "Uttar Pradesh",
    "Uttarakhand",
    "West Bengal",
    "Andaman and Nicobar Islands",
    "Chandigarh",
    "Dadra and Nagar Haveli",
    "Daman and Diu",
    "Lakshadweep",
    "National Capital Territory of Delhi",
    "Puducherry"
  ];
  String? selecteditem = "";
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      resizeToAvoidBottomInset: false,
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image(
              image: AssetImage('Assets/images/splashscreen.png'),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                decoration: InputDecoration(
                    hintText: 'Address Line1', border: OutlineInputBorder()),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Address Line2',
                  border: OutlineInputBorder(),
                ),
              ),
            ),
            // Padding(
            //   padding: const EdgeInsets.all(10.0),
            //   child: TextField(
            //     decoration: InputDecoration(
            //       hintText: 'City',
            //       border: OutlineInputBorder(),
            //     ),
            //   ),
            // ),
            // Dropdown(),
            Padding(
              padding: const EdgeInsets.all(10.0),
              // child: ListTile(
              //   title: TextField(
              //     decoration: InputDecoration(
              //         border: OutlineInputBorder(), hintText: 'Pincode'),
              //   ),
              // ),
            ),

            //   ],
            // ),
            Row(
              children: [
                Text(
                  'State : ',
                  style: TextStyle(fontSize: 20),
                ),
                Expanded(
                  child: ListTile(
                    title: DropdownButtonFormField<String>(
                      decoration: InputDecoration(border: OutlineInputBorder()),
                      hint: Text('Select State '),
                      value: selecteditem,
                      items: items
                          .map((item) => DropdownMenuItem<String>(
                              value: item,
                              child: Text(
                                item,
                                style: TextStyle(fontSize: 20),
                              )))
                          .toList(),
                      onChanged: (item) => setState(() => selecteditem = item),
                    ),
                  ),
                ),
                Expanded(
                    child: ListTile(
                  title: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        TextFormField(
                          decoration: InputDecoration(
                              // hintText: 'Enter text',
                              ),
                          textAlign: TextAlign.center,
                          validator: (text) {
                            if (text!.length <= 0 || text.length > 6) {
                              return 'Enter valid pin';
                            }
                            return null;
                          },
                        ),
                        ElevatedButton(
                          onPressed: () {
                            if (_formKey.currentState!.validate()) {
                              // TODO submit
                            }
                          },
                          child: Text('Submit'),
                        )
                      ],
                    ),
                  ),
                )),
              ],
              //  , Padding(
              //     padding: const EdgeInsets.all(10.0),
              //     child: ListTile(
              //       title: DropdownButtonFormField<String>(
              //         decoration: InputDecoration(border: OutlineInputBorder()),
              //         hint: Text('Select State '),
              //         value: selecteditem,
              //         items: items
              //             .map((item) => DropdownMenuItem<String>(
              //                 value: item,
              //                 child: Text(
              //                   item,
              //                   style: TextStyle(fontSize: 20),
              //                 )))
              //             .toList(),
              //         onChanged: (item) => setState(() => selecteditem = item),
              //       ),
              //     ),
              //   ),
            ),
            SizedBox(
              height: 70,
              child: Center(
                  child: ButtonTheme(
                minWidth: 700,
                height: 20,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => Page8(),
                        ));
                  },
                  child: Text('Next'),
                ),
              )),
            ),
          ],
        ),
      ),
    ));
  }
}
