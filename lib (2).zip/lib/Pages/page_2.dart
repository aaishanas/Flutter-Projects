// ignore_for_file: prefer_const_constructors, duplicate_ignore, unnecessary_import, implementation_imports

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Page2 extends StatelessWidget {
  const Page2({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return SafeArea(
      child: Scaffold(
        body: Column(children: [
          Stack(children: [
            Container(
              height: 300,
              width: 1400,
              color: Color.fromARGB(255, 179, 211, 180),
            ),
            Center(
              child: Positioned(
                top: 40,
                left: 80,
                right: 80,
                bottom: 10,
                child: Image(
                  image: AssetImage(
                    'Assets/images/deliveryout.png',
                  ),
                  height: 300,
                  width: 400,
                ),
              ),
            )
          ]),
          Column(
            // ignore: prefer_const_literals_to_create_immutables
            children: [
              Text(
                '\n Real Time Reporting ',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w200,
                ),
              ),
              Text(
                '\n \n  Keeping track of real-time delivery location',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w100,
                ),
              ),
            ],
          ),
        ]),
      ),
    );
  }
}
