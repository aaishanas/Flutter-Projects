// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:my_first/Pages/page_10.dart';

class Page9 extends StatelessWidget {
  const Page9({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // ignore: prefer_const_constructors
    return Scaffold(
      // ignore: prefer_const_constructors
      body: Column(
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          Center(
              // ignore: prefer_const_constructors
              child: Image(
            image: const AssetImage('Assets/images/splashscreen.png'),
          )),
          Center(
            child: Text(
              'Enable Location',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ),
          Center(
            child: Text(
              '\n We will need your location to give you better experience.',
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(top: 100),
            child: ElevatedButton(
              onPressed: () {},
              child: Text('Enable location'),
            ),
          ),
          Center(
              child: TextButton(
            onPressed: () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (context) => Page10()));
            },
            child: Text('Not now'),
          )),
        ],
      ),
    );
  }
}
