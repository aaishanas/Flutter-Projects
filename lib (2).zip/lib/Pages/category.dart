// ignore_for_file: prefer_const_constructors, prefer_final_fields

import 'package:flutter/material.dart';
import 'package:my_first/Pages/page_10.dart';

class Category extends StatefulWidget {
  const Category({Key? key}) : super(key: key);

  @override
  State<Category> createState() => _CategoryState();
}

class _CategoryState extends State<Category> {
  TextEditingController _controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Row(
              children: [
                Container(
                    child: IconButton(
                        onPressed: () {
                          Navigator.pop(
                              context,
                              MaterialPageRoute(
                                builder: (context) => Page10(),
                              ));
                        },
                        icon: Icon(
                          Icons.arrow_back,
                        ))),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    style: TextStyle(),
                    decoration: InputDecoration(
                        prefixIcon: Icon(
                          Icons.search,
                        ),
                        border:
                            OutlineInputBorder(borderRadius: BorderRadius.zero),
                        hintText: "search your needs here...."),
                  ),
                ),
              ],
            ),
            Expanded(
              child: Column(
                // ignore: prefer_const_literals_to_create_immutables
                children: [
                  Text(
                    "Category",
                    style: TextStyle(color: Colors.green, fontSize: 50),
                  ),
                  Expanded(
                    child: GridView(
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 60,
                      ),
                      primary: false,
                      padding: const EdgeInsets.all(20),
                      children: <Widget>[
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/basket_full_vegetables_1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Vegetables"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/nuts-walnut-peanuts-almond-seeds 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Dry Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/basket_full_vegetables_1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Vegetables"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/nuts-walnut-peanuts-almond-seeds 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Dry Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/basket_full_vegetables_1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Vegetables"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/nuts-walnut-peanuts-almond-seeds 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Dry Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/whole-chicken-sliced-carrots-plate-burlap-napkin-blue-surface 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Meat"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.green[100],
                              borderRadius: BorderRadius.circular(20)),
                          height: 30,
                          width: 20,

                          child: Column(
                            children: [
                              Image.asset(
                                  'Assets/Images/category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1.png'),
                              SizedBox(
                                  child: Expanded(
                                      child: Padding(
                                padding: const EdgeInsets.only(bottom: 0),
                                child: Text("Fruits"),
                              )))
                            ],
                          ),
                          // color: Colors.green[200],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
