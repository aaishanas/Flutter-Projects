// ignore_for_file: prefer_const_constructors, avoid_unnecessary_containers

import 'package:flutter/material.dart';

class Page4 extends StatelessWidget {
  const Page4({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(children: [
        Container(
          alignment: Alignment.center,
          height: 300,
          width: 350,
          child: Image(image: AssetImage('Assets/images/splashscreen.png')),
        ),
        Container(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.people),
                  hintText: 'Username',
                  hintStyle: TextStyle(color: Colors.red)),
            ),
          ),
        ),
        Container(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              // obscureText: pass,
              decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.lock),
                  suffixIcon: Icon(Icons.remove_red_eye),
                  hintText: 'Password',
                  hintStyle: TextStyle(color: Colors.red)),
            ),
          ),
        ),
        Container(
          child: Text(
            'Forgot password?',
            textAlign: TextAlign.right,
          ),
        ),
        SizedBox(
          child: Container(
              // alignment: Alignment.center,
              child: ButtonTheme(
            minWidth: 700,
            height: 20,
            child: ElevatedButton(
              child: Text('Login'),
              onPressed: () {},
              // style: ButtonStyle(
              //     backgroundColor: MaterialStateProperty.all(Colors.red),
              //     padding: MaterialStateProperty.all(EdgeInsets.all(50)),
              //     textStyle:
              //         MaterialStateProperty.all(TextStyle(fontSize: 30))
              //         ),
            ),
          )),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          Center(child: Text('Dont have an acoount?')),
          Expanded(
            child: TextButton(
                onPressed: () {},
                child: Text(
                  'Sign Up',
                  style: TextStyle(color: Colors.green),
                )),
          )
        ]),
        Center(child: Text('Or')),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(child: Image.asset('Assets/images/google.png')),
            Container(
                child: SizedBox(
                    height: 60,
                    width: 30,
                    child: Image.asset('Assets/images/fb.png'))),
          ],
        )
      ]),
    );
  }
}
