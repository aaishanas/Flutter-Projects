// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:my_first/Pages/page_6.dart';

class Page5 extends StatelessWidget {
  const Page5({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Center(
            child: Container(
              child: Image(image: AssetImage('Assets/images/splashscreen.png')),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: TextField(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: 'Enter username',
              ),
            ),
          ),
          SizedBox(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                    hintText: 'Enter password',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.remove_red_eye)),
              ),
            ),
          ),
          SizedBox(
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: TextField(
                obscureText: true,
                decoration: InputDecoration(
                    hintText: 'Confirm password',
                    border: OutlineInputBorder(),
                    suffixIcon: Icon(Icons.remove_red_eye)),
              ),
            ),
          ),
          ElevatedButton(
              onPressed: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => Page6()));
              },
              child: Text(
                'Next',
              ))
        ],
      ),
    );
  }
}
