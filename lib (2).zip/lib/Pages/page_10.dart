// ignore_for_file: unused_field, prefer_const_constructors, avoid_unnecessary_containers, unused_local_variable

import 'package:flutter/material.dart';
import 'package:my_first/Pages/category.dart';
import 'package:my_first/Pages/homescreenwidgets/Bannerwidget.dart';
import 'package:my_first/Pages/homescreenwidgets/CardWidget.dart';
import 'package:my_first/Pages/homescreenwidgets/Categorycard.dart';
import 'package:my_first/Pages/homescreenwidgets/searchbar.dart';
import 'package:my_first/constant.dart';

class Page10 extends StatefulWidget {
  const Page10({Key? key}) : super(key: key);

  @override
  State<Page10> createState() => _Page10State();
}

class _Page10State extends State<Page10> {
  // ignore: prefer_final_fields

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            padding: EdgeInsets.only(left: 10, right: 10, top: 20),
            child: SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Image.asset('Assets/Images/splashscreen.png'),
                      IconButton(
                          color: Colors.green,
                          iconSize: 25,
                          onPressed: () {},
                          icon: Icon(Icons.notifications)),
                    ],
                  ),

                  SizedBox(
                      height: 10,
                      child: Searchbar(
                        wid: 335,
                      )),

                  SizedBox(height: 10, child: Bannerwidget()),
                  SizedBox(
                    height: 10,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text("Category", style: categoryTextStyle),
                        TextButton(
                          onPressed: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => Category(),
                                ));
                          },
                          child: Text(
                            "View all",
                            style: viewAllTextStyle,
                          ),
                        ),
                      ],
                    ),
                  ),

                  SizedBox(
                    height: 10,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        CategoryWidget(
                          image:
                              "Assets/Images/Category/basket_full_vegetables_1",
                          text: 'Vegetables',
                        ),
                        CategoryWidget(
                          image:
                              "Assets/Images/Category/colorful-fruits-tasty-fresh-ripe-juicy-white-desk 1",
                          text: "Fruits",
                        ),
                        CategoryWidget(
                            text: "Dry Fruits",
                            image:
                                "Assets/Images/Category/nuts-walnut-peanuts-almond-seeds 1"),
                        CategoryWidget(
                            text: "Meat",
                            image:
                                "Assets/Images/Category/whole-chicken-sliced-carrots-plate-burlap-napkin-blue-surface 1")
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("Offers"),
                      ],
                    ),
                  ),
                  // ignore: prefer_const_literals_to_create_immutables
                  SizedBox(
                    width: 335,
                    height: 159,
                    child: ListView(
                      shrinkWrap: true,
                      scrollDirection: Axis.horizontal,
                      children: [
                        Image.asset("Assets/Images/Banner bigg 1.png"),
                        Image.asset("Assets/Images/Orange banner 1.png")
                      ],
                    ),
                  ),

                  SizedBox(
                    height: 20,
                    child: Row(
                      // ignore: prefer_const_literals_to_create_immutables
                      children: [
                        Text("Best Selling Products"),
                        TextButton(
                            onPressed: () {},
                            child: Text(
                              "View all",
                              style: viewAllTextStyle,
                            ))
                      ], //Navigator.push(MaterialPageRoute(builder: (context) =>SellingProducts(),)
                    ),
                  ),

                  SizedBox(
                      height: 10,
                      child: Row(
                        children: [
                          CardWidget(
                            image: "Assets/Images/tomatoes 1.png",
                            text: "Fresh organic Tomato\n500g",
                            price: "₹ 30",
                          ),
                          CardWidget(
                            image:
                                "Assets/Images/orange-juicy-ripe-circle-citrus 1.png",
                            text: "Fresh Organic Orange\n500g",
                            price: "₹ 50",
                          )
                        ],
                      ))
                ],
              ),
            )));
  }
}
