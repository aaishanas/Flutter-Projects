// ignore_for_file: prefer_const_constructors, unnecessary_import, implementation_imports

import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class Page1 extends StatelessWidget {
  const Page1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Stack(children: [
            Container(
              height: 300,
              width: 1400,
              color: Color.fromARGB(255, 179, 211, 180),
            ),
            Center(
              child: Positioned(
                top: 40,
                left: 80,
                right: 80,
                bottom: 10,
                child: Image(
                  image: AssetImage(
                    'Assets/images/deliveryboy.png',
                  ),
                  height: 300,
                  width: 400,
                ),
              ),
            ),
          ]),
          Column(
            // ignore: prefer_const_literals_to_create_immutables
            children: [
              Text(
                '\n Shop your daily needs ',
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.w200,
                ),
              ),
              Text(
                '\n \n  Set your delivery location. Choose your groceries  from a wide range required products',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w100,
                ),
              ),
            ],
          ),
          //   ElevatedButton(onPressed: (){
          //     MaterialPageRoute(builder: context,Navigat)}, child: context()=>)
        ],
      ),
    );
  }
}
