// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class Bannerwidget extends StatelessWidget {
  const Bannerwidget({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // ignore: prefer_const_literals_to_create_immutables
      body: SizedBox(
        height: 335,
        width: 125,
        child: ListView(
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            children: [
              Image(image: AssetImage("Assets/Images/1st banner 2 1")),
              SizedBox(
                  child:
                      Image(image: AssetImage("Assets/Images/Banner bigg 1"))),
              Image(image: AssetImage("Assets/Images/Orange banner 1")),
            ]),
      ),
    );
  }
}
