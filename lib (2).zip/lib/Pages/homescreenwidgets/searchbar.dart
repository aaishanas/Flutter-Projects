// ignore_for_file: prefer_const_constructors, use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:my_first/constant.dart';

class Searchbar extends StatelessWidget {
  Searchbar({required this.wid});
  double wid;

  @override
  Widget build(BuildContext context) {
    TextEditingController _textcontroller = TextEditingController();
    return Scaffold(
      body: Container(
        width: wid,
        height: 40,
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextFormField(
            controller: _textcontroller,
            style: searchBarHintTextTextStyle,
            decoration: InputDecoration(
                prefixIcon: Icon(
                  Icons.search,
                ),
                border: OutlineInputBorder(borderRadius: BorderRadius.zero),
                hintText: "search your needs here...."),
          ),
        ),
      ),
    );
  }
}
