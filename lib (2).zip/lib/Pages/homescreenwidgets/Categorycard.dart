import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';
import 'package:flutter/widgets.dart';
import 'package:my_first/constant.dart';

class CategoryWidget extends StatelessWidget {
  CategoryWidget({required this.text, required this.image});
  String text;
  String image;
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        Image.asset(image),
        Text(
          text,
          style: cardTextStyle,
        )
      ],
    );
  }
}
