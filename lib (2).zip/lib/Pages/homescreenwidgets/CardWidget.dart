import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter/src/widgets/placeholder.dart';

class CardWidget extends StatelessWidget {
  CardWidget({required this.image, required this.text, required this.price});
  String image;
  String text;
  String price;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: ListView(
        children: [
          Image.asset(image),
          Text(text),
          Text(price),
        ],
      ),
    );
  }
}
